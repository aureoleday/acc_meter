# -*- coding: utf-8 -*-
"""
Created on Mon Dec  3 15:52:21 2018

@author: Administrator
"""

import socket
import threading
import time
import struct
import queue
import serial

import numpy as np
from ringbuf import RingBuffer
import matplotlib.pyplot as plt 
from matplotlib import animation

SYNC_HEAD = b'\xdf\x1b\xdf\x9b'

# 0 4000Hz
# 1 2000Hz
# 2 1000Hz
# 3 500Hz
# 4 250Hz
# 5 125Hz
# 6 62.5Hz
# 7 31.25Hz
# 8 15.625Hz
# 9 7.813Hz
# 10 3.906Hz

FILTER_REG = 64

FS = 4000>>(FILTER_REG&0x0f)

#FS = 4000
WINDOW_SIZE = 1024

fft_size = WINDOW_SIZE

rb = RingBuffer(WINDOW_SIZE,1)
in_buf = []
inb_q = queue.Queue(0)
#gain = 3.9e-6

def calc_ord(reg_val):
    fs = 4000>>(reg_val&0x0f)
    lpf = fs/4
    lpf_reg = reg_val>>4
    if(lpf_reg == 0 ):
        hpf = 0
    else:
        hpf = 0.247*fs/(4**(lpf_reg-1))
    return fs,lpf,hpf


def func(a):
    temp = struct.unpack('f',struct.pack('L',a))
    return temp    

def checksum(arr_in):
    xsum = 0
    for item in arr_in:
        xsum ^=item
    return xsum

def pkg_resolve():
    arr = []
    frame = []
    flag = 0
    q_len = inb_q.qsize()
    pkg_len = 99
    if q_len != 0:
        for i in range(q_len):
            temp = inb_q.get(block=False)
            arr.append(temp)
            if flag > 0:
                delta = i-flag
                if (delta&3 == 0):
                    if(4 == delta):
                        CMD = int.from_bytes(bytes(arr[-4:]),byteorder='little', signed=False)
                        frame.append(CMD)
                        pkg_len = CMD&0x0ffff
                    elif((delta>>2) > pkg_len+1):
                        buf = int.from_bytes(bytes(arr[-4:]),byteorder='little', signed=False)
                        frame.append(buf)
                        if(checksum(frame) != 0):
                            print(frame)
                        break
                    else:
                        buf = int.from_bytes(bytes(arr[-4:]),byteorder='little', signed=False)
                        frame.append(buf)
                        buf = func(buf)
                        rb.append(buf)                    
            elif i>=3:
                if bytes(arr[-4:]) == SYNC_HEAD:
                    buf = int.from_bytes(bytes(arr[-4:]),byteorder='little', signed=False)
                    frame.append(buf)
                    flag = i
                else:
                    print("drop\n")
                    
def t_resolve():
    while True:
        if inb_q.qsize() > 0:
            pkg_resolve()
        time.sleep(0.001)                   

def ser_init():
    ser = serial.Serial("com16",115200)
    print(ser.name)
    if ser.isOpen():
        print("open success")
    else:
        print("open failed")
    try:        
        while True:
            count = ser.inWaiting() 
            if count > 0:
                data = ser.read(count) 
                inb_q.queue.extend(data)
                time.sleep(0.001)
    except KeyboardInterrupt: 
        if serial != None: 
            ser.close()

def tcp_client_init(ip,port):
    ser_ip = ip
    ser_port = port
    tcp_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        tcp_client.connect((ser_ip,ser_port))
        print('connected')
        while True:
            data = tcp_client.recv(4096)
            if data != '':
                inb_q.queue.extend(data)                
            time.sleep(0.002)
        tcp_client.close()
        print('Connection closed.')
    except socket.error:
        print("fail to setup socket connection")
    tcp_client.close()
        

def sys_init(mode,ip,port):

    threads = []
    if mode == 1:
        t1 = threading.Thread(target=tcp_client_init,args=(ip,port))
    elif mode == 2:
        t1 = threading.Thread(target=ser_init)
    threads.append(t1)
    t2 = threading.Thread(target=t_resolve)
    threads.append(t2)
    for t in threads:
        t.setDaemon(True)
        t.start()

fig = plt.figure()
ax = fig.add_subplot(211)
af = fig.add_subplot(212)
 
x = np.arange(0,WINDOW_SIZE)/FS
xh = np.arange(0,WINDOW_SIZE/2+1)*FS/WINDOW_SIZE

linex, = ax.plot(x,np.sin(x),color='r')
linexf, = af.plot(xh,np.sin(xh),color='g')

def gen_frames():
    yield 0

def choose_windows(name='Hanning', N=20): # Rect/Hanning/Hamming 
    if name == 'Hamming':
        window = np.array([0.54 - 0.46 * np.cos(2 * np.pi * n / (N - 1)) for n in range(N)]) 
    elif name == 'Hanning':
        window = np.array([0.5 - 0.5 * np.cos(2 * np.pi * n / (N - 1)) for n in range(N)]) 
    elif name == 'Rect':
        window = np.ones(N) 
    return window

def my_fft(din):
    temp = din[:fft_size]*choose_windows(N=fft_size)
    fftx = np.fft.rfft(temp)/fft_size
    xfp = np.abs(fftx)*2
    return xfp

def update(i):
    temp = rb.view
    habx = my_fft(temp[:,0])

    linex.set_ydata(temp[:,0])
    ax.set_ylim(np.min(temp[:,0]),np.max(temp[:,0]))
    linexf.set_ydata(habx)
    af.set_ylim(np.min(habx),np.max(habx))
        
#    return linex,

def initial():
    linex.set_ydata(np.sin(x))
    linexf.set_ydata(np.zeros(int(WINDOW_SIZE/2 + 1)))
    ax.set_ylim(-3000,3000)
#    ax.set_xlabel("time")
    ax.set_ylabel("x(g)")
    af.set_ylim(-3000,3000)
#    af.set_xlabel("freq")
    af.set_ylabel("Amp-x")
    return linex,

try:
    FS,LPF,HPF = calc_ord(FILTER_REG)
    print("FS:%.3f,LPF:%.3f,HPF:%.3f\n" % (FS,LPF,HPF))
    sys_init(mode=1,ip="192.168.1.101",port=9996)
#    sys_init(mode=1,ip="192.168.4.1",port=9996) 
    ani = animation.FuncAnimation(fig=fig,func=update,frames=gen_frames,init_func=initial,interval=100,blit=False)
    plt.show()
except KeyboardInterrupt:
    pass

